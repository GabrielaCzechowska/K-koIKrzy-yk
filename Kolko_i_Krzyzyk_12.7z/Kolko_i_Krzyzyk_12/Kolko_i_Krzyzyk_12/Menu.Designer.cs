﻿namespace Kolko_i_Krzyzyk_12
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.GraczvsGracz = new System.Windows.Forms.Button();
            this.GraczvsKomputer = new System.Windows.Forms.Button();
            this.PoziomGry = new System.Windows.Forms.Button();
            this.Autor = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // GraczvsGracz
            // 
            this.GraczvsGracz.BackColor = System.Drawing.Color.Black;
            this.GraczvsGracz.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GraczvsGracz.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.GraczvsGracz.Location = new System.Drawing.Point(48, 16);
            this.GraczvsGracz.Name = "GraczvsGracz";
            this.GraczvsGracz.Size = new System.Drawing.Size(240, 61);
            this.GraczvsGracz.TabIndex = 0;
            this.GraczvsGracz.Text = "Gracz vs Gracz";
            this.GraczvsGracz.UseVisualStyleBackColor = false;
            this.GraczvsGracz.Click += new System.EventHandler(this.GraczvsGracz_Click);
            // 
            // GraczvsKomputer
            // 
            this.GraczvsKomputer.BackColor = System.Drawing.Color.Black;
            this.GraczvsKomputer.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GraczvsKomputer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.GraczvsKomputer.Location = new System.Drawing.Point(48, 83);
            this.GraczvsKomputer.Name = "GraczvsKomputer";
            this.GraczvsKomputer.Size = new System.Drawing.Size(240, 61);
            this.GraczvsKomputer.TabIndex = 1;
            this.GraczvsKomputer.Text = "Gracz vs Komputer";
            this.GraczvsKomputer.UseVisualStyleBackColor = false;
            this.GraczvsKomputer.Click += new System.EventHandler(this.GraczvsKomputer_Click);
            // 
            // PoziomGry
            // 
            this.PoziomGry.BackColor = System.Drawing.Color.Black;
            this.PoziomGry.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PoziomGry.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PoziomGry.Location = new System.Drawing.Point(306, 16);
            this.PoziomGry.Name = "PoziomGry";
            this.PoziomGry.Size = new System.Drawing.Size(240, 61);
            this.PoziomGry.TabIndex = 2;
            this.PoziomGry.Text = "Poziom Gry";
            this.PoziomGry.UseVisualStyleBackColor = false;
            this.PoziomGry.Click += new System.EventHandler(this.PoziomGry_Click);
            // 
            // Autor
            // 
            this.Autor.BackColor = System.Drawing.Color.Black;
            this.Autor.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Autor.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Autor.Location = new System.Drawing.Point(306, 83);
            this.Autor.Name = "Autor";
            this.Autor.Size = new System.Drawing.Size(240, 61);
            this.Autor.TabIndex = 2;
            this.Autor.Text = "Autor";
            this.Autor.UseVisualStyleBackColor = false;
            this.Autor.Click += new System.EventHandler(this.Autor_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(584, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.Autor);
            this.panel1.Controls.Add(this.GraczvsGracz);
            this.panel1.Controls.Add(this.GraczvsKomputer);
            this.panel1.Controls.Add(this.PoziomGry);
            this.panel1.Location = new System.Drawing.Point(0, 158);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 157);
            this.panel1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Purple;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 391);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(925, 27);
            this.panel2.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(610, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(315, 334);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(925, 418);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GraczvsGracz;
        private System.Windows.Forms.Button GraczvsKomputer;
        private System.Windows.Forms.Button PoziomGry;
        private System.Windows.Forms.Button Autor;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

