﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolko_i_Krzyzyk_12
{
    public partial class GraczVSgracz : Form
    {
        Menu f1;
        public GraczVSgracz()
        {
            InitializeComponent();
        }
        public GraczVSgracz(Menu f)
        {
            InitializeComponent();
            f1 = f;
        }

        private void GraczVSgracz_FormClosing(object sender, FormClosingEventArgs e)
        {
            f1.Visible = true;
        }

        public int player = 2; // evem= X turn; add- 0 turn;
        public int turns = 0; // counmting turns; 
        // counting wins for both players and draws;
        public int s1 = 0;
        public int s2 = 0;
        public int sd = 0;

        private void buttonClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (button.Text == "")
            {
                if (player % 2 == 0)
                {
                    button.Text = "X";
                    player++;
                    turns++;
                }
                else
                {
                    button.Text = "O";
                    player++;
                    turns++;
                }
                if (CheckDraw() == true)
                {
                    MessageBox.Show("Remis! Sprbój jeszcze raz! ");
                    sd++;
                    NewGame();
                }
                if (CheckWinner() == true)
                {
                    if (button.Text == "X")
                    {
                        MessageBox.Show("Gracz grający krzyżykiem, wygrał! GRATULACJE!");
                        s1++;
                        NewGame();
                    }
                    else
                    {
                        MessageBox.Show("Gracz grający kółkiem, wygrał! GRATULACJE!");
                        s2++;
                        NewGame();
                    }

                }
            }
        }

        private void EButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            XWin.Text = "Ilość Wygranych Grającego Krzyżykiem: " + s1;
            OWin.Text = "Ilość Wygranych Grającego Kółkiem:: " + s2;
            Draws.Text = "Remisy: " + sd;
        }
        void NewGame()
        {
            player = 2;
            turns = 0;
            A00.Text = A01.Text = A02.Text = A10.Text = A11.Text = A12.Text = A20.Text = A21.Text = A22.Text = "";
            XWin.Text = "Ilość Wygranych Grającego Krzyżykiem:" + s1;
            OWin.Text = "Ilość Wygranych Grającego Kółkiem: " + s2;
            Draws.Text = "Remisy: " + sd;
        }

        private void NGButton_Click(object sender, EventArgs e)
        {
            NewGame();
        }
        bool CheckDraw()
        {
            if ((turns == 9) && CheckWinner() == false)
                return true;
            else
                return false;
        }
        bool CheckWinner()
        {
            //horizontal checks
            if ((A00.Text == A01.Text) && (A01.Text == A02.Text) && A00.Text != "")
                return true;
            else if ((A10.Text == A11.Text) && (A11.Text == A12.Text) && A10.Text != "")
                return true;
            else if ((A20.Text == A21.Text) && (A21.Text == A22.Text) && A20.Text != "")
                return true;

            //vertical checks
            if ((A00.Text == A10.Text) && (A10.Text == A20.Text) && A00.Text != "")
                return true;
            else if ((A01.Text == A11.Text) && (A11.Text == A21.Text) && A01.Text != "")
                return true;
            else if ((A02.Text == A12.Text) && (A12.Text == A22.Text) && A02.Text != "")
                return true;

            //diagomal checks
            if ((A00.Text == A11.Text) && (A11.Text == A22.Text) && A00.Text != "")
                return true;
            else if ((A02.Text == A11.Text) && (A11.Text == A20.Text) && A02.Text != "")
                return true;
            else
                return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            s1 = s2 = sd = 0;
            NewGame();
        }
    }
}
    

