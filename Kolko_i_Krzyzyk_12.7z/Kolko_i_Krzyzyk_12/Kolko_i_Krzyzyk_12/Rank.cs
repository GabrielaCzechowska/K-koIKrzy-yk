﻿using System;

namespace Kolko_i_Krzyzyk_12
{
    public class Rank : IEquatable<Rank>

    {
        public string Name { get; set; }

        public int Surename { get; set; }

        public override string ToString()
        {
            return "ID: " + Name + "   Name: " + Surename;
        }
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            Ranking objAsPart = obj as Ranking;
            if (objAsPart == null) return false;
            else return Equals(objAsPart);
        }
        public override int GetHashCode()
        {
            return Surename;
        }
        public bool Equals(Part other)
        {
            if (other == null) return false;
            return (this.PartId.Equals(other.PartId));
        }

        public bool Equals(Rank other)
        {
            throw new NotImplementedException();
        }
        // Should also override == and != operators.
    }
}
}
