﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolko_i_Krzyzyk_12
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void GraczvsGracz_Click(object sender, EventArgs e)
        {
            GraczVSgracz o2 = new GraczVSgracz(this);
            this.Visible = false;
            o2.ShowDialog();
        }

        private void GraczvsKomputer_Click(object sender, EventArgs e)
        {
            {
                GraczVSkomputer o3 = new GraczVSkomputer(this);
                this.Visible = false;
                o3.ShowDialog();
            }
        }

        private void PoziomGry_Click(object sender, EventArgs e)
        {
            {
                PoziomGry o4 = new PoziomGry(this);
                this.Visible = false;
                o4.ShowDialog();
            }

        }

        private void Autor_Click(object sender, EventArgs e)
        {
            {
                Autor o5 = new Autor(this);
                this.Visible = false;
                o5.ShowDialog();
            }
        }
    }
}

