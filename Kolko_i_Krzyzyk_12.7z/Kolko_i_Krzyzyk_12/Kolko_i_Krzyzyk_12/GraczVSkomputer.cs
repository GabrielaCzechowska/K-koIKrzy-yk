﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolko_i_Krzyzyk_12
{
    public partial class GraczVSkomputer : Form
    {
        Menu f1;
        public GraczVSkomputer()
        {
            InitializeComponent();
        }

        public GraczVSkomputer(Menu f)
        {
            InitializeComponent();
            f1 = f;
        }

        private void GraczVSkomputer_FormClosing(object sender, FormClosingEventArgs e)
        {
            f1.Visible = true;
        }
    }
}
    


/*
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int player = 1; // evem= X turn; add- 0 turn; 1
        public int turns = 0; // counmting turns; 
        // counting wins for both players and draws;
        public int s1 = 0;
        public int s2 = 0;
        public int sd = 0;

        private void ButtonClick(object sender, EventArgs e)
        {
            {
                Button button = (Button)sender;
                if (button.Text == "")
                {
                    if (player % 2 == 0)
                    {
                        button.Text = "X";
                        player++;
                        turns++;
                    }
                    /*else
                    {
                        button.Text = "O";
                        player++;
                        turns++;
                    }*/
                    /*
                    if (CheckDraw() == true)
                    {
                        MessageBox.Show("Remis! Sprbój jeszcze raz! ");
                        sd++;
                        NewGame();
                    }

                    if (CheckWinner() == true)
                    {
                        if (button.Text == "X")
                        {
                            MessageBox.Show("Gracz grający krzyżykiem, wygrał! GRATULACJE!");
                            s1++;
                            NewGame();
                        }
                        else
                        {
                            MessageBox.Show("Gracz grający kółkiem, wygrał! GRATULACJE!");
                            s2++;
                            NewGame();
                        }
                    }
                }
            }
        }

        private void Ebutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           //Win.Text = "Ilość Wygranych Grającego Krzyżykiem: " + s1;
           //Win.Text = "Ilość Wygranych Grającego Kółkiem:: " + s2;
          //Draws.Text = "Remisy: " + sd;
        }
        void NewGame()
        {
            player = 2;
            turns = 0;
            A00.Text = A01.Text = A02.Text = A10.Text = A11.Text = A12.Text = A20.Text = A21.Text = A22.Text = "";
           //Win.Text = "Ilość Wygranych Grającego Krzyżykiem:" + s1;
          //OWin.Text = "Ilość Wygranych Grającego Kółkiem: " + s2;
          //Draws.Text = "Remisy: " + sd;
        }

        private void NGButton_Click(object sender, EventArgs e)
        {
            NewGame();
        }
        bool CheckDraw()
        {
            if ((turns == 9) && CheckWinner() == false)
                return true;
            else
                return false;
        }
        bool CheckWinner()
        {
            //horizontal checks
            if ((A00.Text == A01.Text) && (A01.Text == A02.Text) && A00.Text != "")
                return true;
            else if ((A10.Text == A11.Text) && (A11.Text == A12.Text) && A10.Text != "")
                return true;
            else if ((A20.Text == A21.Text) && (A21.Text == A22.Text) && A20.Text != "")
                return true;

            //vertical checks
            if ((A00.Text == A10.Text) && (A10.Text == A20.Text) && A00.Text != "")
                return true;
            else if ((A01.Text == A11.Text) && (A11.Text == A21.Text) && A01.Text != "")
                return true;
            else if ((A02.Text == A12.Text) && (A12.Text == A22.Text) && A02.Text != "")
                return true;

            //diagomal checks
            if ((A00.Text == A11.Text) && (A11.Text == A22.Text) && A00.Text != "")
                return true;
            else if ((A02.Text == A11.Text) && (A11.Text == A20.Text) && A02.Text != "")
                return true;
            else
                return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            s1 = s2 = sd = 0;
            NewGame();
        }
    }
}




/*
namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int sm = 0;
        public int sc = 0;
        public int sd = 0;

        public int turns = 0;

        public bool onturn = true;





        private void Form1_Load(Object sender, EventArgs e)
        {

        }


        private void RST_Click(object sender, EventArgs e)
        {

        }

        public Button CPU()
        {
            Button b = null;
            b = CPUTryWinorDefend("O");
            if (b != null)
                return b;
            else
            {
                b = CPUTryWinorDefend("X");
                if (b != null)
                    return b;
                else
                    return NewMethod();
            }
        }

        private Button NewMethod()
        {
            throw new NotImplementedException();
        }

        /* private Button NewMethod()
         {
            return CPUMoveRandom();
         }*/
/*
public Button CPUTryWinorDefend(string s)
{
   Button b = null;
   if ((A00.Text) == (A01.Text) && A00.Text == s && A02.Text == "")
       return A02;
   else if(A00.Text == A02.Text && A00.Text == s && A01.Text == "")
       return A01;
   else if(A01.Text == A02.Text && A01.Text == s && A00.Text == "")
       return A00;

   else if(A10.Text == A12.Text && A10.Text == s && A11.Text == "")
       return A11;
   else if (A10.Text == A11.Text && A10.Text == s && A02.Text == "")
       return A02;
   else if (A12.Text == A11.Text && A11.Text == s && A10.Text == "")
       return A10;

   else if (A20.Text == A22.Text && A20.Text == s && A21.Text == "")
       return A21;
   else if (A20.Text == A21.Text && A20.Text == s && A22.Text == "")
       return A22;
   else if (A22.Text == A21.Text && A22.Text == s && A20.Text == "")
       return A20;

   //vertical checks
   else if (A00.Text == A10.Text && A00.Text == s && A20.Text == "")
       return A20;
   else if (A00.Text == A20.Text && A00.Text == s && A10.Text == "")
       return A10;
   else if (A20.Text == A10.Text && A10.Text == s && A00.Text == "")
       return A00;

   else if (A21.Text == A11.Text && A11.Text == s && A01.Text == "")
       return A01;
   else if (A21.Text == A01.Text && A01.Text == s && A11.Text == "")
       return A11;
   else if (A01.Text == A11.Text && A01.Text == s && A21.Text == "")
       return A21;

   else if (A22.Text == A12.Text && A12.Text == s && A02.Text == "")
       return A02;
   else if (A22.Text == A02.Text && A02.Text == s && A12.Text == "")
       return A12;
   else if (A02.Text == A12.Text && A01.Text == s && A22.Text == "")
       return A22;

   //diagonal checks
   else if (A00.Text == A11.Text && A11.Text == s && A22.Text == "")
       return A22;
   else if (A22.Text == A00.Text && A11.Text == s && A22.Text == "")
       return A11;
   else if (A22.Text == A11.Text && A11.Text == s && A00.Text == "")
       return A00;

   else if (A20.Text == A11.Text && A11.Text == s && A02.Text == "")
       return A02;
   else if (A20.Text == A02.Text && A02.Text == s && A11.Text == "")
       return A11;
   else if (A02.Text == A11.Text && A11.Text == s && A20.Text == "")
       return A20;

   else
       return null;
}
public Button CPUMoveRandom()
{
   Button b = null;
   foreach (Control C in Controls)
   {
       b = C as Button;
       if (b != null)
       {
           if (b.Text == "")
               return b;
       }
   }

   return null;
}
          private void button_clicked(object sender, EventArgs e)
{
   Button b = (Button)sender;
   {
       if (b.Text == "")
       {
           if (onturn == true)
               b.Text = "X";
           else
               b.Text = "O";
           turns++;
           onturn = !onturn;
       }

       if (CheckWinner() == true)
       {
           if (onturn == false)
           {
               sm++;
               MessageBox.Show("Wygrałeś!");
               NewGame();
           }
           else
           {
               sc++;
               MessageBox.Show("Komputer Wygrał!");
               NewGame();
           }
       }
       if (checkDraw() == true && CheckWinner() == false)

       {
           sd++;
           MessageBox.Show("Remis!");
               NewGame();
       }
       if (onturn == false)
       {
           CPU().PerformClick();
       }

   }
}

private bool checkDraw()
{
   throw new NotImplementedException();
}

private bool CheckWinner()
{
   throw new NotImplementedException();
}

public void NewGame()
{
   A00.Text = A01.Text = A02.Text = A10.Text = A11.Text = A12.Text = A20.Text = A21.Text = A22.Text = "";
   turns = 0;
   onturn = true;
   //Myscore.Text = sm.ToString();
  // CPUScore.Text = sc.ToString();
}














/*
   b = CPUTryWinorDefend("O");
   if (b != null)
       return b;
   else
   {
       b = CPUTryWinorDefend("X");
       if (b != null)
           return b;
       else
           return CPUMoveRandom();
   }
}
public Button CPUTryWinorDefend(string s)
{
   Button b = null;
   if ((A00.Text) == (A01.Text) && A00.Text == s && A02.Text == "")
       return A02;
   else if (A00.Text == A02.Text && A00.Text = s && A01.Text == "")
       return A01;
   else if (A01.Text == A02.Text && A01.Text == s && A00.Text == "")
       return A00;
   else if (A10.Text == A12.Text && A10.Text == s && A11.Text == "")
       return; A11;
   else if (A10.Text == A11.Text && A10.Text == s && A02.Text == "")
       return A02;
}







}
}
public Button CPUTryWinorDefend(string s)
{
   Button b = null;
   //horizontal checks
   if ((A00.Text) == (A01.Text) && A00.Text == s && A02.Text == "")
       return A02;
   else if (A00.Text == A02.Text && A00.Text == s && A01.Text == "")
       return A01;
   else if (A01.Text == A02.Text && A01.Text == s && A00.Text == "")
       return A00;


   else if (A10.Text == A12.Text && A10.Text == s && A11.Text == "")
       return A11;
   else if (A10.Text == A11.Text && A10.Text == s && A02.Text == "")
       return A02;
   else if (A12.Text == A11.Text && A11.Text == s && A10.Text == "")
       return A10;

   else if (A20.Text == A22.Text && A20.Text == s && A21.Text == "")
       return A21;
   else if (A20.Text == A21.Text && A20.Text == s && A22.Text == "")
       return A22;
   else if (A22.Text == A21.Text && A22.Text == s && A20.Text == "")
       return A20;

   //vertical checks
   else if (A00.Text == A10.Text && A00.Text == s && A20.Text == "")
       return A20;
   else if (A00.Text == A20.Text && A00.Text == s && A10.Text == "")
       return A10;
   else if (A20.Text == A10.Text && A10.Text == s && A00.Text == "")
       return A00;

   else if (A21.Text == A11.Text && A11.Text == s && A01.Text == "")
       return A01;
   else if (A21.Text == A01.Text && A01.Text == s && A11.Text == "")
       return A11;
   else if (A01.Text == A11.Text && A01.Text == s && A21.Text == "")
       return A21;

   else if (A22.Text == A12.Text && A12.Text == s && A02.Text == "")
       return A02;
   else if (A22.Text == A02.Text && A02.Text == s && A12.Text == "")
       return A12;
   else if (A02.Text == A12.Text && A01.Text == s && A22.Text == "")
       return A22;

   //diagonal checks
   else if (A00.Text == A11.Text && A11.Text == s && A22.Text == "")
       return A22;
   else if (A22.Text == A00.Text && A11.Text == s && A22.Text == "")
       return A11;
   else if (A22.Text == A11.Text && A11.Text == s && A00.Text == "")
       return A00;

   else if (A20.Text == A11.Text && A11.Text == s && A02.Text == "")
       return A02;
   else if (A20.Text == A02.Text && A02.Text == s && A11.Text == "")
       return A11;
   else if (A02.Text == A11.Text && A11.Text == s && A20.Text == "")
       return A20;

   else
       return null;
}
*/
/*  public Button CPUMoveRandom()
  {
  Button b = null;
  foreach(Control C in Controls)
  {
  b= C as Button;
  if(b!=null)
  {
  if (bool.Text == "")
      return bool;
  }
}
  return null;
}*/

/*
private void button_clicked(object sender, EventArgs e)
{
Button b = (Button)sender;
if (b.Text == "")
{
if (onTurn == true)
{
if (onturn == true)
b.Text = "X";
else
b.Text = "O'
turns++;
onturn = !onturn

if (CheckWinner() == true)
{
if (onturn == false)
{
sm++
MessageBox.Show("Wygrałeś!");
NewGame();
}
else
{
sc++
MessageBox.Show("Komputer Wygrał!");
NewGame();
}
}
if (checkDraw() == true && CheckWinner () == false)
{
sd++ 
MessageBox.Show("Remis!");
NewGame();
}
if (onturn == false)
*/






    
    

