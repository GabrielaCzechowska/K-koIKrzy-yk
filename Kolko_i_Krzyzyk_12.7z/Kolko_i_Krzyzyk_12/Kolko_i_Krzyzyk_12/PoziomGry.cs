﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolko_i_Krzyzyk_12
{
    public partial class PoziomGry : Form
    {
        Menu f1;
        public PoziomGry()
        {
            InitializeComponent();
        }

        public PoziomGry(Menu f)
        {
            InitializeComponent();
            f1 = f;
            comboBox1.DataSource = Enum.GetValues(typeof(Poziom_Gry));
            //CheckedListBox
        }

        private void PoziomGry_FormClosing(object sender, FormClosingEventArgs e)
        {
            f1.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.Add(comboBox1.SelectedItem.ToString());
        }
    }
    public enum Poziom_Gry
    {
        Łatwy, Normalny, Trudny, Koszmar


    }
}




            /*
              class Rank : IEquatable<Rank>

    {
        public string Name { get; set; }

        public string Surename { get; set; }

        public override object ToString()
        {
            return "ID: " + Name + "   Name: " + Surename;
        }
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            Ranking objAsRank = obj as Rank;
            if (objAsRank == null) return false;
            else return Equals(objAsRank);
        }
        public override int GetHashCode()
        {
            return Surename;
        }

            
        }
    }

    */
