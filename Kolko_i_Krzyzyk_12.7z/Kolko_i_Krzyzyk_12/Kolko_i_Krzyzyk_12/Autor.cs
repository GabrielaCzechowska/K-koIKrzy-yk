﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kolko_i_Krzyzyk_12
{
    public partial class Autor : Form
    {
        Menu f1;
        public Autor()
        {
            InitializeComponent();
        }

        public Autor(Menu f)
        {
            InitializeComponent();
            f1 = f;
        }

        private void Autor_FormClosing(object sender, FormClosingEventArgs e)
        {
            f1.Visible = true;
        }
    }
}
